
from app.routes.auth import auth_bp
from app.routes.gold import bp as gold_bp
from app.routes.affiliate import affiliate_bp
from app.routes.main import bp as main_bp

